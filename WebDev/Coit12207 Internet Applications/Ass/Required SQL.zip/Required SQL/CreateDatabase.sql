drop database if exists computer;
create database computer;
grant SELECT, INSERT, UPDATE, DELETE ON computer.* TO 'webauth'@'localhost';
use computer;
create table jobs
(id int unsigned not null auto_increment primary key,
  customer_name varchar(100) not null,
  email varchar(100) not null,
  severity int not null,
  description varchar(1000) not null
);
create table authorized_users
(username varchar(20) not null primary key,
  password varchar(40)
);
insert into authorized_users values
  ('sam', sha1('password'));
insert into jobs values
  (1, 'Joe Blogs', 'joe.b@cqu.edu.au', 1, 'Computer will not turn on'),
  (2, 'Jane Doe', 'jane.d@cqu.edu.au', 2, 'Mobile screen broken'),
  (3, 'Sam Smith', 'sam.s@cqu.edu.au', 3, 'Forgot password');